function menuShow() {
    let menuMobile = document.querySelector('.mobile-menu');
    if (menuMobile.classList.contains('open')) {
        menuMobile.classList.remove('open');
        document.querySelector('.icon').src = "assets/img/menu_white_36dp.svg";
    } else {
        menuMobile.classList.add('open');
        document.querySelector('.icon').src = "assets/img/close_white_36dp.svg";
    }
}


/*Codigo para o icone de pesquisa*/

let search = document.querySelector('.search-box');

document.querySelector('#search-icon').onclick = () => {
        search.classList.toggle('active');
}


let header = document.querySelector('header');

window.addEventListener('scroll' , () => {
        header.classList.toggle('shadow', window.scrollY > 0);
});

/*Codigo para o resumo nutricional ao clicar no botao ira mostrar toda a informação*/
// script.js
document.addEventListener('DOMContentLoaded', function () {
    const nutritionSummary = document.querySelector('.nutritionsummary');
    const toggleButton = document.getElementById('toggleButton');

    toggleButton.addEventListener('click', function () {
        if (nutritionSummary.classList.contains('reduced')) {
            nutritionSummary.classList.remove('reduced');
            toggleButton.textContent = 'Ver menos';
        } else {
            nutritionSummary.classList.add('reduced');
            toggleButton.textContent = 'Ver mais';
        }
    });
});

class MobileNavbar {
    constructor(mobileMenu, navList, navLinks) {
      this.mobileMenu = document.querySelector(mobileMenu);
      this.navList = document.querySelector(navList);
      this.navLinks = document.querySelectorAll(navLinks);
      this.activeClass = "active";
  
      this.handleClick = this.handleClick.bind(this);
    }
  
    animateLinks() {
      this.navLinks.forEach((link, index) => {
        link.style.animation
          ? (link.style.animation = "")
          : (link.style.animation = `navLinkFade 0.5s ease forwards ${
              index / 7 + 0.3
            }s`);
      });
    }
  
    handleClick() {
      this.navList.classList.toggle(this.activeClass);
      this.mobileMenu.classList.toggle(this.activeClass);
      this.animateLinks();
    }
  
    addClickEvent() {
      this.mobileMenu.addEventListener("click", this.handleClick);
    }
  
    init() {
      if (this.mobileMenu) {
        this.addClickEvent();
      }
      return this;
    }
  }
  
  const mobileNavbar = new MobileNavbar(
    ".mobile-menu",
    ".nav-list",
    ".nav-list li",
  );
  mobileNavbar.init();

/* javascript barra de pesquisa*/

function filterRecipes() {
    let input = document.getElementById('search-bar').value.toLowerCase();
    let recipes = document.getElementsByClassName('recipe');
    let main = document.querySelector('main');
    let hasVisibleRecipes = false;

    for (let i = 0; i < recipes.length; i++) {
        let recipeName = recipes[i].getAttribute('data-recipe-name').toLowerCase();
        if (recipeName.includes(input)) {
            recipes[i].style.display = "block";
            hasVisibleRecipes = true;
        } else {
            recipes[i].style.display = "none";
        }
    }

    if (input === "" || !hasVisibleRecipes) {
        main.style.display = "none";
    } else {
        main.style.display = "block";
    }
}

// Função para exibir/ocultar conteúdo extra
function toggleContent(button) {
    var extraContent = button.previousElementSibling;
    if (extraContent.style.display === "block") {
        extraContent.style.display = "none";
        button.innerText = "Ver Mais";
    } else {
        extraContent.style.display = "block";
        button.innerText = "Ver Menos";
    }
}

// Função para exibir mais receitas
function toggleMoreRecipes() {
    var hiddenRecipes = document.querySelectorAll('.recipe-card.hidden');
    hiddenRecipes.forEach(function(recipe) {
        recipe.classList.toggle('hidden');
    });
    var btn = document.getElementById('show-more-btn');
    btn.style.display = 'none';
}

// Função para voltar ao topo
function scrollToTop() {
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

// Mostrar o botão de voltar ao topo quando o usuário rola até o final da página
window.addEventListener('scroll', function() {
    var backToTopBtn = document.getElementById('back-to-top');
    var showMoreBtn = document.getElementById('show-more-btn');
    if (window.innerHeight + window.scrollY >= document.body.offsetHeight - 100) {
        backToTopBtn.style.display = 'block';
    } else {
        backToTopBtn.style.display = 'none';
    }
});

// Dados das receitas
const recipesData = [
    { 
        name: "Pescada Crocante no Forno com Puré de Grão",
        image: "images/receitapeixe/pescada-crocante-forno.jpeg",
        link: "Hamburguerangus.html",
        time: "20 min",
        difficulty: "Fácil"
    },
];

// Função para adicionar receitas ao HTML
function addRecipesToPage(recipes) {
    const recipesContainer = document.getElementById("recipes-container");
    recipes.forEach(recipe => {
        const recipeCard = document.createElement("div");
        recipeCard.classList.add("recipe-card");

        const recipeLink = document.createElement("a");
        recipeLink.href = recipe.link;

        const recipeImage = document.createElement("img");
        recipeImage.src = recipe.image;
        recipeImage.alt = recipe.name;

        const recipeInfo = document.createElement("div");
        recipeInfo.classList.add("recipe-info");

        const recipeName = document.createElement("h2");
        recipeName.textContent = recipe.name;

        const recipeTime = document.createElement("p");
        recipeTime.textContent = `${recipe.time} · ${recipe.difficulty}`;

        // Monta a estrutura do HTML
        recipeInfo.appendChild(recipeName);
        recipeInfo.appendChild(recipeTime);
        recipeLink.appendChild(recipeImage);
        recipeLink.appendChild(recipeInfo);
        recipeCard.appendChild(recipeLink);
        recipesContainer.appendChild(recipeCard);
    });
}

// Adiciona as receitas ao carregar a página
window.addEventListener("load", () => {
    addRecipesToPage(recipesData);
});
document.addEventListener("DOMContentLoaded", () => {
    const cards = [
        {
            link: "https://example.com/caldo-verde",
            image: "images/receitassopas/caldo-verde.jpg",
            title: "Caldo verde com chuchu baixo em calorias",
            time: "40 min",
            difficulty: "Fácil"
        },
        {
            link: "https://example.com/madalenas-chocolate",
            image: "images/receitassobremesas/madalenas-chocolate.jpg",
            title: "Madalenas com Chocolate Yämmi",
            time: "11 min",
            difficulty: "Médio"
        },
        {
            link: "https://example.com/tarte-tatin",
            image: "images/receitassobremesas/tarte-tatin.jpg",
            title: "Tarte tatin de pera rocha e nozes",
            time: "30 min",
            difficulty: "Fácil"
        },
        {
            link: "https://example.com/sobremesa-ananas",
            image: "images/receitassobremesas/sobremesa-ananas.jpg",
            title: "Sobremesa de Ananás dos Açores, Suspiro e Chantilly",
            time: "20 min",
            difficulty: "Fácil"
        },
        {
            link: "https://example.com/broas-mel",
            image: "images/receitassobremesas/broas-mel.jpg",
            title: "Broas de mel simples e portuguesas",
            time: "45 min",
            difficulty: "Fácil"
        }
    ];

    const cardContainer = document.getElementById("card-container");
    const randomIndex = Math.floor(Math.random() * cards.length);
    const selectedCard = cards[randomIndex];

    const cardHTML = `
        <div class="recipe-card">
            <a href="${selectedCard.link}">
                <img src="${selectedCard.image}" alt="${selectedCard.title}">
                <div class="recipe-info">
                    <h2>${selectedCard.title}</h2>
                    <p>${selectedCard.time} · ${selectedCard.difficulty}</p>
                </div>
            </a>
        </div>
    `;

    cardContainer.innerHTML = cardHTML;
});